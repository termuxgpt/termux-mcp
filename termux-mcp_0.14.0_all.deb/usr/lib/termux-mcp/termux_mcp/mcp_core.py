import json
import logging
import os
import signal
import subprocess
import threading
import time
import uuid
from typing import Callable, Optional


from . import mcp_bridge
from . import mcp_config as cfg
from .config import COMMAND_TIMEOUT, HOME, MAX_OUTPUT_BYTES
from .safety import snapshot_targets_from_command
from .security import get_risk_assessment
from .shell import preprocess, set_current_dir
from .styling import STYLE_TOOLS, run_style_tool
from .terminal import interactive_program, run_terminal_tool
from .approval import APPROVAL_TOOLS, run_approval_tool
from .smart import MCP_DEFS as SMART_TOOL_DEFS, SMART_TOOLS, run_smart_tool
from .playbook import requirement_ids
from .utils import expand_home, kill_process_group, shell_quote, split_cd_chain
from .websocket import _session_capture, _spawn_auto_input


logger = logging.getLogger(__name__)


PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603


DEFAULT_TMUX_SESSION = "termux-mcp"
_TRUNCATION_MARKER = (
    f"\n[Output truncated: max {MAX_OUTPUT_BYTES} bytes — "
    f"full output not sent]\n"
)


NATIVE_TOOL_DEFS = [
    {
        "name": "run",
        "description": (
            "Execute a shell command in Termux with streaming output. "
            "Maintains persistent cd state for this MCP session. Long jobs: "
            "use session_run/session_poll instead. Risky commands are "
            "blocked or need confirmed: true."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "cmd": {"type": "string", "description": "Shell command"},
                "confirmed": {"type": "boolean",
                              "description": "Acknowledge a risk warning",
                              "default": False},
            },
            "required": ["cmd"],
        },
    },
    {
        "name": "cancel",
        "description": "Cancel the command currently running in this session.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "session_start",
        "description": "Start (or ensure) a persistent tmux session.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "session": {"type": "string",
                            "description": "Session name",
                            "default": DEFAULT_TMUX_SESSION},
            },
        },
    },
    {
        "name": "session_run",
        "description": (
            "Run a command in a tmux session WITHOUT blocking — returns "
            "immediately with initial output; poll with session_poll."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "session": {"type": "string",
                            "description": "Session name",
                            "default": DEFAULT_TMUX_SESSION},
                "cmd": {"type": "string",
                        "description": "Command to run in the session"},
            },
            "required": ["cmd"],
        },
    },
    {
        "name": "session_poll",
        "description": "Get new output from a running tmux session.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "session": {"type": "string",
                            "description": "Session name",
                            "default": DEFAULT_TMUX_SESSION},
            },
        },
    },
    {
        "name": "session_list",
        "description": "List live tmux sessions.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "session_kill",
        "description": "Kill a tmux session.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "session": {"type": "string",
                            "description": "Session name",
                            "default": DEFAULT_TMUX_SESSION},
            },
        },
    },

    {
        "name": "terminal_open",
        "description": (
            "Open a live interactive terminal (a real PTY). The user sees it "
            "and can type into it alongside you. Use this INSTEAD OF run for "
            "anything that needs a terminal: cmatrix, vim, vi, nano, emacs, "
            "htop, top, less, more, man, fzf, lazygit, tmux, ssh, mysql, psql, "
            "sqlite3, python, python3, node, irb, and any full-screen or "
            "prompt-driven program. Also use it when a command would wait for "
            "input (a password, a y/n prompt, an editor). Returns a session id."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "cmd": {"type": "string",
                        "description": "Optional command to start immediately"},
                "cols": {"type": "integer", "default": 80},
                "rows": {"type": "integer", "default": 24},
                "confirmed": {"type": "boolean",
                              "description": "Acknowledge a risk warning",
                              "default": False},
            },
        },
    },
    {
        "name": "terminal_run",
        "description": (
            "Type a command into an open terminal and press Enter. Risk-checked "
            "the same way run is. Use this to launch an interactive program in "
            "an existing session."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "session": {"type": "string",
                            "description": "Session id from terminal_open"},
                "cmd": {"type": "string", "description": "Command to type"},
                "confirmed": {"type": "boolean",
                              "description": "Acknowledge a risk warning",
                              "default": False},
            },
            "required": ["session", "cmd"],
        },
    },
    {
        "name": "terminal_send",
        "description": (
            "Send raw keystrokes to an open terminal — for driving a program "
            "that is waiting for input, not for running commands (use "
            "terminal_run for that). Control characters: Ctrl+C '\\u0003', "
            "Ctrl+D '\\u0004', Ctrl+Z '\\u001a', Ctrl+L '\\u000c', Escape "
            "'\\u001b', Enter '\\r', Tab '\\t'. Arrow keys: '\\u001b[A' up, "
            "'\\u001b[B' down, '\\u001b[C' right, '\\u001b[D' left."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "session": {"type": "string"},
                "data": {"type": "string",
                         "description": "Raw characters to send"},
            },
            "required": ["session", "data"],
        },
    },
    {
        "name": "terminal_read",
        "description": (
            "Read what an open terminal currently shows. Returns recent screen "
            "text with control sequences stripped. Prefer this over asking the "
            "user to copy output."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "session": {"type": "string"},
                "max_bytes": {"type": "integer", "default": 4000},
            },
            "required": ["session"],
        },
    },
    {
        "name": "terminal_list",
        "description": "List open terminal sessions and whether the user is watching.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "terminal_close",
        "description": "Close a terminal session, terminating its shell and any program in it.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "session": {"type": "string"},
            },
            "required": ["session"],
        },
    },

    {
        "name": "theme_list",
        "description": (
            "List the Termux colour themes that can be applied. Use this "
            "first to find a name the user will recognise. Some names exist "
            "as both dark and light."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "theme_preview",
        "description": (
            "Show what a theme looks like without applying it — one name as "
            "theme, or several at once as themes. Nothing on the device "
            "changes, and the app draws the palette for the user, so use "
            "this to offer two or three options when they have not decided. "
            "Then call theme_apply with the one they pick."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "theme": {"type": "string", "description": "Theme name"},
                "themes": {
                    "type": "array", "items": {"type": "string"},
                    "description": "Several names, previewed in one call",
                },
                "shade": {"type": "string",
                          "description": "dark or light, when both exist"},
            },
        },
    },
    {
        "name": "theme_apply",
        "description": (
            "Apply a colour theme to the user's Termux, changing how every "
            "shell on the device looks. Returns the palette so the user can "
            "see it. Needs confirmed: true — the first call returns a "
            "confirmation request to put to the user."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "theme": {"type": "string", "description": "Theme name"},
                "shade": {"type": "string",
                          "description": "dark or light, when both exist"},
                "confirmed": {"type": "boolean", "default": False},
            },
            "required": ["theme"],
        },
    },
    {
        "name": "theme_revert",
        "description": (
            "Undo a theme change: either restore the colours that were in "
            "place before the last one, or go back to Termux's own defaults. "
            "Needs confirmed: true."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "to": {"type": "string",
                       "description": "'previous' (default) or 'default'",
                       "default": "previous"},
                "confirmed": {"type": "boolean", "default": False},
            },
        },
    },
    {
        "name": "font",
        "description": (
            "Preview terminal text styles — figlet and toilet fonts — by "
            "drawing a sample word. action: \"list\" names what is installed "
            "(query filters); action: \"preview\" draws it in one or more "
            "fonts so the user can choose. Nothing is installed or changed, "
            "and no real terminal font is touched. Put the chosen name into "
            "banner_render."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string",
                           "description": "'list' or 'preview'",
                           "default": "preview"},
                "text": {"type": "string",
                         "description": "Sample to draw, under 40 characters"},
                "fonts": {"type": "string",
                          "description": "Comma-separated font names to draw"},
                "query": {"type": "string",
                          "description": "For action: list — filter by name"},
                "filter": {"type": "string",
                           "description": "toilet effect, e.g. metal, border, flip"},
            },
        },
    },
    {
        "name": "banner_render",
        "description": (
            "Render text as a large ASCII banner with figlet. Use this rather "
            "than drawing the art yourself — the user sees the result "
            "immediately, and it can then be written to the terminal's "
            "message of the day."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string",
                         "description": "Text to render, under 60 characters"},
                "font": {"type": "string",
                         "description": "figlet font name, optional"},
            },
            "required": ["text"],
        },
    },
    {
        "name": "approve",
        "description": (
            "Ask the user to approve one exact action on the device itself — "
            "their fingerprint, or a dialog when no fingerprint is enrolled. "
            "Use this before a command the risk gate calls risky, so the "
            "user sees what is about to run. The approval lasts a few "
            "minutes and is spent when that same action runs."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "The exact command or action, verbatim",
                },
                "reason": {
                    "type": "string",
                    "description": "One line shown to the user",
                },
                "method": {
                    "type": "string", "enum": ["fingerprint", "dialog"],
                    "description": "Defaults to fingerprint",
                },
            },
            "required": ["action"],
        },
    },
    {
        "name": "ask",
        "description": (
            "Ask the user with a real Android dialog rather than guessing — "
            "text, number, radio, sheet, spinner, checkbox, date, time or "
            "speech. Use it for a choice or a value only they know: which "
            "folder, which port, which day. Returns what they chose, or that "
            "they cancelled."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "widget": {
                    "type": "string",
                    "enum": ["text", "number", "radio", "sheet", "spinner",
                             "checkbox", "date", "time", "speech"],
                    "description": "Defaults to text",
                },
                "title": {
                    "type": "string",
                    "description": "The question, kept short",
                },
                "hint": {
                    "type": "string",
                    "description": "Placeholder, for text and speech",
                },
                "values": {
                    "type": "array", "items": {"type": "string"},
                    "description": "The choices, for radio, sheet, spinner "
                                   "and checkbox. No backslashes.",
                },
                "multiline": {
                    "type": "boolean",
                    "description": "Let text run to several lines",
                },
                "format": {
                    "type": "string",
                    "description": "Date format, for date",
                },
            },
            "required": ["widget"],
        },
    },
]

NATIVE_TOOL_DEFS += SMART_TOOL_DEFS


class RpcError(Exception):
    def __init__(self, code: int, message: str) -> None:
        super().__init__(message)
        self.code = code


class MCPSession:

    def __init__(self, sid: str, transport: str) -> None:
        self.sid = sid
        self.transport = transport
        self.cwd = HOME
        self.created = time.time()
        self.protocol_version: Optional[str] = None
        self.lock = threading.Lock()
        self.killed = threading.Event()
        self.closed = threading.Event()
        self.active_pid: Optional[int] = None
        self.on_line: Optional[Callable[[str], None]] = None
        self.tmux_seen = {}
        self.last_used = time.monotonic()

    def touch(self) -> None:
        self.last_used = time.monotonic()

    def expired(self, ttl: float) -> bool:
        return time.monotonic() - self.last_used > ttl

    def kill_active(self) -> bool:
        pid = self.active_pid
        if pid is None:
            return False
        return _kill_process_group(pid)


def _kill_process_group(pid: int) -> bool:
    killpg = getattr(os, "killpg", None)
    getpgid = getattr(os, "getpgid", None)
    try:
        if killpg is not None and getpgid is not None:
            killpg(getpgid(pid), signal.SIGTERM)
        else:
            os.kill(pid, signal.SIGTERM)
        return True
    except (ProcessLookupError, OSError):
        return False


_SESSIONS = {}
_SESSIONS_LOCK = threading.Lock()


def create_session(transport: str) -> MCPSession:
    sid = uuid.uuid4().hex
    session = MCPSession(sid, transport)
    with _SESSIONS_LOCK:
        _SESSIONS[sid] = session
    return session


def get_session(sid: str, touch: bool = True):
    with _SESSIONS_LOCK:
        session = _SESSIONS.get(sid)
        if session is None:
            return None
        if session.expired(cfg.session_ttl()):
            _SESSIONS.pop(sid, None)
            return None
    if touch:
        session.touch()
    return session


def drop_session(sid: str) -> None:
    with _SESSIONS_LOCK:
        session = _SESSIONS.pop(sid, None)
    if session is not None:
        session.killed.set()
        session.kill_active()
        session.closed.set()


def active_session_count() -> int:
    with _SESSIONS_LOCK:
        return len(_SESSIONS)


def server_info() -> dict:
    return {
        "protocolVersion": cfg.DEFAULT_PROTOCOL_VERSION,
        "capabilities": {"tools": {}, "resources": {}},
        "serverInfo": {"name": cfg.SERVER_NAME, "version": cfg.SERVER_VERSION},
        "instructions": (
            "Termux shell + device tools on this Android device. Commands "
            "stream output; risky commands are blocked or require "
            "confirmed:true. Deletes move to ~/termuxGPT/trash and file "
            "overwrites are snapshotted under ~/termuxGPT/snapshots. "
            "For long jobs use session_run then session_poll."
        ),
    }


def negotiate_protocol(client_version) -> str:
    if client_version in cfg.SUPPORTED_PROTOCOL_VERSIONS:
        return client_version
    return cfg.DEFAULT_PROTOCOL_VERSION


def _cd_into(session: MCPSession, raw_cmd: str):
    path_part, chained = split_cd_chain(raw_cmd[2:].strip())
    if not path_part or path_part == "~":
        session.cwd = HOME
        return True, HOME, chained
    raw_path = expand_home(path_part, HOME)
    new_path = os.path.abspath(
        raw_path if os.path.isabs(raw_path)
        else os.path.join(session.cwd, raw_path)
    )
    if os.path.isdir(new_path):
        session.cwd = new_path
        return True, session.cwd, chained
    return False, f"Directory not found: {new_path}", None


def _notify(session: MCPSession, line: str) -> None:
    cb = session.on_line
    if cb is not None:
        try:
            cb(line)
        except Exception:
            session.on_line = None


def _execute_command(session: MCPSession, raw_cmd: str) -> dict:
    session.killed.clear()
    process = None
    limit = 0
    watchdog = None
    sent_bytes = 0
    truncated = False
    chunks = []

    def append(text: str) -> None:
        chunks.append(text)
        _notify(session, text)

    try:
        from . import kernel
        kwargs = {"shell": True, "stdout": subprocess.PIPE,
                  "stderr": subprocess.STDOUT, "stdin": subprocess.PIPE,
                  "text": True, "cwd": session.cwd}
        kwargs.update(kernel.popen_kwargs())
        limit = kernel.timeout_for(raw_cmd)
        timed_out = threading.Event()
        process = subprocess.Popen(
            f"export PAGER=cat; {preprocess(raw_cmd)}", **kwargs
        )
        session.active_pid = process.pid
        _spawn_auto_input(process, raw_cmd)

        def _on_timeout():
            timed_out.set()
            session.killed.set()

        watchdog = kernel.arm_watchdog(process, limit, _on_timeout)

        stdout = process.stdout
        if stdout is None:
            append("\n❌ Error: no stdout pipe\n")
            process.wait()
        for line in stdout or []:
            if session.killed.is_set():
                append(f"\n⏱️ Timed out after {limit}s\n" if timed_out.is_set()
                       else "\nCancelled\n")
                break
            sent_bytes += len(line.encode())
            if sent_bytes <= MAX_OUTPUT_BYTES:
                append(line)
            elif not truncated:
                truncated = True
                append(_TRUNCATION_MARKER)

        if watchdog is not None:
            watchdog.join(timeout=2)
        if timed_out.is_set() and not (chunks and "Timed out" in chunks[-1]):
            append(f"\n⏱️ Timed out after {limit}s\n")

        if not session.killed.is_set():
            if process.returncode is None:
                try:
                    process.wait(timeout=2)
                except Exception:
                    pass
            if process.returncode is None:
                append("\nExit: (process detached)\n")
            elif process.returncode == 0:
                append("\n✅ Done\n")
            else:
                append(f"\n❌ Exit code: {process.returncode}\n")
    except Exception as e:
        append(f"\n❌ Error: {e}\n")
    finally:
        kill_process_group(process)
        session.active_pid = None

    meta = mcp_bridge.analyze_output("".join(chunks))
    text = meta["text"]
    if meta["timed_out"]:
        text = (text + "\n" if text else "") + f"Timed out after {limit}s (kernel limit)"
    return {"text": text, "is_error": _error_from_meta(meta)}


def _error_from_meta(meta: dict) -> bool:
    code = meta["exit_code"]
    return meta["error"] or meta["timed_out"] or (code not in (None, 0))


def _tool_run(session: MCPSession, params: dict) -> dict:
    p = params or {}
    cmd = str(p.get("cmd", "")).strip()
    confirmed = bool(p.get("confirmed", False))
    if not cmd:
        return {"text": "Missing 'cmd'", "is_error": True}

    from . import kernel
    decision = kernel.gate(cmd, confirmed=confirmed, cwd=session.cwd)
    if not decision["allow"] and decision["status"] != "confirm":
        return {"text": decision["message"], "is_error": True,
                "code": decision["code"]}
    if decision["status"] == "confirm":
        return {
            "text": (decision["message"] + "\n\nRe-invoke with `confirmed: true` "
                     "to proceed, or approve this exact command on the device "
                     "with the approve tool first."),
            "is_error": False,
        }

    interactive = interactive_program(cmd)
    if interactive and not confirmed:
        return {
            "text": (
                f"`{interactive}` needs a terminal. `run` gives it a pipe, not a "
                f"tty, so it cannot draw and will likely block forever waiting "
                f"for input.\n\nUse `terminal_open` (optionally with cmd) to run "
                f"it in a real terminal the user can see and type into.\n\nIf you "
                f"genuinely want it non-interactively, re-invoke with "
                f"`confirmed: true`."
            ),
            "is_error": False,
        }

    cmd, snaps = kernel.prepare(cmd, str(p.get("task_id", "")))
    if snaps and cmd.startswith("cd"):
        logger.info("Snapshots taken (cd command, not echoed): %s", snaps)

    if cmd.startswith("cd"):
        ok, msg, chained = _cd_into(session, cmd)
        if not ok:
            return {"text": str(msg), "is_error": True}
        if chained is None:
            return {"text": str(msg), "is_error": False}
        return _execute_command(session, chained)
    return _execute_command(session, cmd)


def _tool_cancel(session: MCPSession) -> dict:
    session.killed.set()
    ok = session.kill_active()
    return {"text": ("Cancelled." if ok else "Nothing running."),
            "is_error": False, "cancelled": ok}


def _ensure_tmux(session: MCPSession, name: str) -> None:
    alive = os.popen(
        f"tmux has-session -t {name} 2>/dev/null && echo yes || echo no"
    ).read().strip() == "yes"
    if not alive:
        os.system(f"tmux new-session -d -s {name} 2>/dev/null")
        os.system(f"tmux set-option -t {name} history-limit 20000 2>/dev/null")
    session.tmux_seen.setdefault(name, 0)


def _tool_session(session: MCPSession, name: str, params: dict) -> dict:
    p = params or {}
    sess_name = str(p.get("session") or DEFAULT_TMUX_SESSION)

    if name == "session_start":
        _ensure_tmux(session, sess_name)
        return {"text": f"Session '{sess_name}' ready.", "is_error": False}

    if name == "session_list":
        out = os.popen(
            "tmux list-sessions 2>/dev/null || echo 'No sessions (tmux not installed?)'"
        ).read().strip()
        return {"text": out, "is_error": False}

    if name == "session_kill":
        os.system(f"tmux kill-session -t {sess_name} 2>/dev/null")
        session.tmux_seen.pop(sess_name, None)
        return {"text": f"Killed: {sess_name}", "is_error": False}

    if name == "session_run":
        cmd = str(p.get("cmd", "")).strip()
        if not cmd:
            return {"text": "Missing cmd", "is_error": True}
        _ensure_tmux(session, sess_name)
        os.system(f"tmux send-keys -t {sess_name} {shell_quote(cmd)} Enter")
        time.sleep(1.2)
        seen = session.tmux_seen[sess_name]
        initial, session.tmux_seen[sess_name] = _session_capture(
            sess_name, seen)
        preview = initial.strip()
        if len(preview) > 2000:
            preview = preview[-2000:]
        return {"text": (
            f"Started in session '{sess_name}':\n{preview or '(no output yet — use session_poll)'}"
        ), "is_error": False}

    if name == "session_poll":
        _ensure_tmux(session, sess_name)
        seen = session.tmux_seen[sess_name]
        output, session.tmux_seen[sess_name] = _session_capture(
            sess_name, seen)
        alive = os.popen(
            f"tmux has-session -t {sess_name} 2>/dev/null && echo yes || echo no"
        ).read().strip() == "yes"
        preview = output.strip()
        if len(preview) > 4000:
            preview = preview[-4000:]
        return {"text": preview or "(no new output)",
                "is_error": False, "running": alive}

    return {"text": f"Unknown session tool: {name}", "is_error": True}


def _tool_terminal(session: MCPSession, name: str, params: dict) -> dict:
    return run_terminal_tool(name, params)


def invoke_tool(session: MCPSession, name: str, params: dict,
                on_progress=None) -> dict:
    p = params or {}
    if not isinstance(p, dict):
        raise RpcError(INVALID_PARAMS, "Tool arguments must be an object")

    if name == "cancel":
        return _tool_cancel(session)

    from . import kernel, obs
    principal = kernel.current_principal()
    refusal = kernel.authorize_tool(name, p, principal)
    if refusal:
        return {"text": refusal, "is_error": True}
    with obs.timed("mcp", name) as call:
        result = _invoke(session, name, p, on_progress)
        call.result(result)
        return result


def _invoke(session: MCPSession, name: str, p: dict, on_progress=None) -> dict:

    old_cb = session.on_line
    session.on_line = on_progress
    try:
        if name in NATIVE_NAMES:
            with session.lock:
                if name == "run":
                    return _tool_run(session, p)
                if name.startswith("terminal_"):
                    return _tool_terminal(session, name, p)
                if name in STYLE_TOOLS:
                    return run_style_tool(name, p)
                if name in APPROVAL_TOOLS:
                    return run_approval_tool(name, p)
                if name in SMART_TOOLS:
                    return run_smart_tool(name, p)
                return _tool_session(session, name, p)

        route = mcp_bridge.route_callable(name)
        if route is None:
            raise RpcError(INVALID_PARAMS, f"Unknown tool: {name}")
        with session.lock:

            set_current_dir(session.cwd)
            vh = mcp_bridge.VirtualHandler()
            route(vh, p)
            return mcp_bridge.decode_virtual(vh)
    finally:
        session.on_line = old_cb


NATIVE_NAMES = frozenset(d["name"] for d in NATIVE_TOOL_DEFS)


def tool_list() -> dict:
    tools = mcp_bridge.build_mcp_tool_list(NATIVE_TOOL_DEFS,
                                           cfg.tools_filter())
    return {"tools": tools}


def check_tool_allowed(name: str) -> None:
    if not mcp_bridge.tool_name_allowed(name, cfg.tools_filter()):
        raise RpcError(INVALID_PARAMS, f"Tool is disabled: {name}")


def call_tool(session: MCPSession, name: str, params: dict,
              on_progress=None) -> dict:
    if not isinstance(name, str) or not name:
        raise RpcError(INVALID_PARAMS, "Missing tool name")
    check_tool_allowed(name)
    result = invoke_tool(session, name, params, on_progress)
    content = []
    text = result.get("text", "")
    if text:
        content.append({"type": "text", "text": text})
    if not content:
        content.append({"type": "text", "text": "(no output)"})
    out: dict = {"content": content}
    if isinstance(result.get("digest"), dict):
        out["structuredContent"] = result["digest"]
    if result.get("is_error"):
        out["isError"] = True
    for key in ("cancelled", "running"):
        if key in result:
            out[key] = result[key]
    return out


PLAYBOOK_URI = "playbook://"
LIBRARY_URI = "library://index"
RUN_URI = "run://"


def resource_list() -> dict:
    from .playbook import list_runs, load_library

    library = load_library()
    resources = [{
        "uri": LIBRARY_URI,
        "name": "Playbook library",
        "description": "Every task this phone can run with no model, and the "
                       "checks it knows how to repair",
        "mimeType": "application/json",
    }]
    for name, playbook in sorted(library["playbooks"].items()):
        resources.append({
            "uri": f"{PLAYBOOK_URI}{name}",
            "name": playbook.get("title") or name,
            "description": "; ".join(playbook.get("phrases") or []),
            "mimeType": "application/json",
        })
    resources += [
        {"uri": "termux://graph", "name": "Device graph",
         "description": "Packages, commands, projects, services and cron on this phone",
         "mimeType": "application/json"},
        {"uri": "termux://changes", "name": "Recent changes",
         "description": "Every file write/delete this server recorded, newest first",
         "mimeType": "application/json"},
        {"uri": "termux://health", "name": "Health report",
         "description": "Last stored device health report", "mimeType": "application/json"},
        {"uri": "termux://context", "name": "Context pack",
         "description": "Compact environment summary", "mimeType": "application/json"},
    ]
    for record in list_runs(limit=10):
        resources.append({
            "uri": f"{RUN_URI}{record.get('task_id')}",
            "name": f"Run {record.get('task_id')}",
            "description": f"{record.get('playbook')} — "
                           f"{'ok' if record.get('ok') else 'failed'}"
                           + (" (undone)" if record.get("undone") else ""),
            "mimeType": "application/json",
        })
    return {"resources": resources}


def resource_read(uri: str) -> dict:
    from .playbook import load_library, load_run

    if uri.startswith("termux://"):
        from .smart import context as _ctx, graph as _graph, health as _health
        from . import changes as _changes, safety as _safety
        from .smart.base import load_output
        key = uri[len("termux://"):]
        if key == "graph":
            body = {"stats": _graph.stats(), "projects": _graph.query("projects")["facts"]["projects"],
                    "services": _graph.query("services")["facts"]["services"]}
        elif key == "changes":
            body = {"changes": _changes.read(_safety.safety_root(""), limit=50)}
        elif key == "health":
            body = _health.report()
        elif key == "context":
            body = _ctx.pack()
        elif key.startswith("out/"):
            text = load_output(key[4:])
            if text is None:
                raise RpcError(INVALID_PARAMS, f"No stored output {key[4:]}")
            return {"contents": [{"uri": uri, "mimeType": "text/plain", "text": text}]}
        else:
            raise RpcError(INVALID_PARAMS, f"Unknown resource: {uri}")
        return {"contents": [{"uri": uri, "mimeType": "application/json",
                              "text": json.dumps(body, indent=1, default=str)}]}
    if uri.startswith(PLAYBOOK_URI):
        name = uri[len(PLAYBOOK_URI):]
        playbook = load_library()["playbooks"].get(name)
        if playbook is None:
            raise RpcError(INVALID_PARAMS, f"No playbook named {name}")
        body = {k: v for k, v in playbook.items() if not k.startswith("_")}
    elif uri.startswith(RUN_URI):
        record = load_run(uri[len(RUN_URI):])
        if record is None:
            raise RpcError(INVALID_PARAMS, f"No run at {uri}")
        body = record
    elif uri == LIBRARY_URI:
        library = load_library()
        body = {
            "playbooks": [
                {"id": p["id"], "title": p.get("title"),
                 "category": p.get("category"), "risk": p.get("risk", "safe"),
                 "phrases": p.get("phrases") or [],
                 "requires": requirement_ids(p),
                 "uri": f"{PLAYBOOK_URI}{p['id']}"}
                for p in sorted(library["playbooks"].values(),
                                key=lambda p: p["id"])
            ],
            "checks": [
                {"id": c["id"], "title": c.get("title"),
                 "severity": c.get("severity"), "fix": c.get("fix")}
                for c in sorted(library["checks"].values(),
                                key=lambda c: c["id"])
            ],
            "problems": library["problems"],
        }
    else:
        raise RpcError(INVALID_PARAMS, f"Unknown resource: {uri}")

    return {"contents": [{"uri": uri, "mimeType": "application/json",
                          "text": json.dumps(body, indent=1)}]}


def dispatch(session: MCPSession, method: str, params,
             on_progress=None):
    if not isinstance(method, str) or not method:
        raise RpcError(INVALID_REQUEST, "Missing method")
    session.touch()

    if method == "initialize":
        client_v = (params or {}).get("protocolVersion") if isinstance(
            params, dict) else None
        session.protocol_version = negotiate_protocol(client_v)
        return server_info()
    if method == "ping":
        return {}
    if method == "tools/list":
        return tool_list()
    if method == "tools/call":
        params = params or {}
        if not isinstance(params, dict):
            raise RpcError(INVALID_PARAMS, "Invalid parameters")
        name = params.get("name")
        if not isinstance(name, str) or not name:
            raise RpcError(INVALID_PARAMS, "Missing tool name")
        args = params.get("arguments", {})
        if not isinstance(args, dict):
            raise RpcError(INVALID_PARAMS, "Tool arguments must be an object")
        progress = None
        meta = args.get("_meta") if isinstance(args, dict) else None
        if isinstance(meta, dict) and meta.get("progressToken") is not None:
            progress = _ProgressProxy(session, meta["progressToken"],
                                      on_progress)
        return call_tool(session, name, args, on_progress=progress)
    if method == "resources/list":
        return resource_list()
    if method == "resources/read":
        params = params or {}
        if not isinstance(params, dict):
            raise RpcError(INVALID_PARAMS, "Invalid parameters")
        uri = str(params.get("uri") or "")
        if not uri:
            raise RpcError(INVALID_PARAMS, "Missing uri")
        return resource_read(uri)
    if method == "notifications/initialized":
        return None
    raise RpcError(METHOD_NOT_FOUND, f"Method not found: {method}")


class _ProgressProxy:

    def __init__(self, session, token, emit) -> None:
        self.session = session
        self.token = token
        self.emit = emit

    def __call__(self, line: str) -> None:
        if self.emit is not None:
            try:
                self.emit({"jsonrpc": "2.0", "method": "notifications/progress",
                           "params": {"progressToken": self.token,
                                      "progress": 0, "message": line.rstrip()}})
            except Exception:
                self.session.on_line = None
