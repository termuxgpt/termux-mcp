import os
from typing import TYPE_CHECKING

from .. import changes
from ..safety import safety_root, snapshot_before_write
from ..shell import execute_streaming, get_current_dir
from ..utils import json_response, require_int, shell_quote


def _as_int(value, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _text_response(handler, text: str) -> None:
    body = text.encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "text/plain")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)

if TYPE_CHECKING:
    from http.server import BaseHTTPRequestHandler


GIT_SMART_ACTION_CHARS = set(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    " -_./:=@^~+*,%"
)



def handle_diagnose(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    intent = data.get("intent", "python").strip()
    checks = []

    if intent in ("python", "pip", "all"):
        checks += [
            'echo "=== Python ==="',
            'python3 --version 2>&1 || echo "Missing: python3"',
            'pip --version 2>&1 || echo "Missing: pip"',
            'python3 -c "import sys; print(sys.executable)" 2>&1 || echo "Cant import sys"',
            'echo "=== PATH ==="',
            'echo "$PATH"',
        ]
    if intent in ("pip", "all"):
        checks += [
            'echo "=== Pip Packages ==="',
            'pip list 2>&1 | head -30 || echo "Pip broken"',
            'pip config list 2>&1 || echo "No pip config"',
        ]
    if intent in ("node", "npm", "all"):
        checks += [
            'echo "=== Node.js ==="',
            'node --version 2>&1 || echo "Missing: nodejs"',
            'npm --version 2>&1 || echo "Missing: npm"',
        ]
    if intent in ("git", "all"):
        checks += [
            'echo "=== Git ==="',
            'git --version 2>&1 || echo "Missing: git"',
        ]
    if intent in ("storage", "all"):
        checks += [
            'echo "=== Storage ==="',
            'ls -la ~/storage/ 2>&1 || echo "Storage not setup - run termux-setup-storage"',
            'df -h /data 2>/dev/null || echo "Cannot check disk"',
        ]
    if intent in ("packages", "all"):
        checks += [
            'echo "=== Packages ==="',
            'pkg list-installed 2>&1 | wc -l || echo "Cant list packages"',
            'apt list --upgradable 2>&1 | head -10 || echo "Cant check updates"',
        ]

    cmd = " && ".join(checks) if checks else 'echo No diagnostic target specified'
    execute_streaming(handler, cmd)



def handle_pkg_smart(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    intent = data.get("intent", "").strip().lower()
    if not intent:
        json_response(handler, 400, {"error": "Missing 'intent'. Describe what you want to do."})
        return

    do_install = data.get("install", False)
    import re

    intent_map = {
        "video":      ("ffmpeg imagemagick", "ffmpeg -version"),
        "edit video": ("ffmpeg imagemagick", "ffmpeg -version"),
        "image":      ("imagemagick", "convert --version"),
        "edit image": ("imagemagick", "convert --version"),
        "photo":      ("imagemagick", "convert --version"),
        "web server": ("python nginx", "python3 --version"),
        "python web": ("python python-pip nginx", "python3 --version"),
        "python":     ("python python-pip", "python3 --version"),
        "node":       ("nodejs", "node --version"),
        "nodejs":     ("nodejs", "node --version"),
        "javascript": ("nodejs", "node --version"),
        "react":      ("nodejs", "node --version"),
        "c":          ("clang make gdb", "clang --version"),
        "c++":        ("clang make gdb", "clang++ --version"),
        "cpp":        ("clang make gdb", "clang++ --version"),
        "rust":       ("rust binutils", "rustc --version"),
        "go":         ("golang", "go version"),
        "java":       ("openjdk-17", "java --version"),
        "ruby":       ("ruby", "ruby --version"),
        "php":        ("php", "php --version"),
        "git":        ("git", "git --version"),
        "database":   ("sqlite mariadb", "sqlite3 --version"),
        "sqlite":     ("sqlite", "sqlite3 --version"),
        "ssh":        ("openssh", "ssh -V 2>&1"),
        "ftp":        ("openssh curl", "curl --version"),
        "editor":     ("vim neovim nano", "vim --version 2>&1 | head -1"),
        "terminal":   ("zsh termux-api fzf bat eza", "zsh --version"),
        "beautiful":  ("zsh eza bat neofetch", "neofetch --version 2>&1"),
        "customize":  ("zsh eza bat neofetch", "neofetch --version 2>&1"),
        "irc":        ("irssi", "irssi --version 2>&1"),
        "bot":        ("python python-pip", "python3 --version"),
        "discord bot":("python python-pip", "python3 --version"),
        "telegram bot":("python python-pip", "python3 --version"),
        "scrape":     ("python python-pip curl", "python3 --version"),
        "scraping":   ("python python-pip curl", "python3 --version"),
        "ocr":        ("tesseract imagemagick", "tesseract --version 2>&1"),
        "text":       ("tesseract imagemagick", "tesseract --version 2>&1"),
        "qr":         ("qrencode zbar", "qrencode --version 2>&1"),
        "barcode":    ("qrencode zbar", "qrencode --version 2>&1"),
        "tor":        ("tor torsocks", "tor --version 2>&1"),
        "speed":      ("speedtest-cli", "speedtest-cli --version 2>&1"),
        "speedtest":  ("speedtest-cli", "speedtest-cli --version 2>&1"),
        "translate":  ("python python-pip", "python3 --version"),
        "science":    ("python python-pip python-numpy", "python3 --version"),
        "data":       ("python python-pip python-numpy python-pandas", "python3 --version"),
        "ml":         ("python python-pip python-numpy", "python3 --version"),
        "ai":         ("python python-pip", "python3 --version"),
        "network":    ("nmap curl wget openssh", "nmap --version 2>&1 | head -1"),
        "hack":       ("nmap python python-pip openssh hydra", "nmap --version 2>&1 | head -1"),
        "pentest":    ("nmap python python-pip openssh hydra", "nmap --version 2>&1 | head -1"),
        "archive":    ("zip unzip tar", "tar --version 2>&1 | head -1"),
        "compress":   ("zip unzip tar", "tar --version 2>&1 | head -1"),
    }

    best_match = None
    best_score = 0
    for key, (pkgs, verify) in intent_map.items():
        score = 0
        for word in intent.split():
            if word in key:
                score += len(word)
        if key == intent:
            score = 999
        elif intent in key or key in intent:
            score = max(score, 900)
        if score > best_score:
            best_score = score
            best_match = (key, pkgs, verify)

    if best_match and best_score > 0:
        key, pkgs, verify_cmd = best_match
        if do_install:
            cmd = f'echo "Installing: {pkgs}"; pkg install -y {pkgs} 2>&1 | tail -20 && echo "---" && {verify_cmd} && echo "Done! All packages installed." || echo "Some packages may have failed."'
        else:
            cmd = f'echo "📦 Suggested packages for: {key}"; echo "Command: pkg install {pkgs}"; echo "---"; echo "Already installed:"; for pkg in {pkgs.split()}; do dpkg -s "$pkg" 2>/dev/null | grep Status | head -1 || echo "  $pkg - NOT installed"; done; echo "---"; echo "To install, use: install: true"'
    else:
        cmd = f'echo No matching packages found for: {shell_quote(intent)}; echo Try broader terms like: python, video, web server, nodejs, c++'

    execute_streaming(handler, cmd)



def handle_explain(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    cmd = data.get("cmd", "").strip()
    if not cmd:
        json_response(handler, 400, {"error": "Missing 'cmd' to explain"})
        return

    qcmd = shell_quote(cmd)
    parts = []
    if "|" in cmd:
        parts.append(f'echo Pipeline: {qcmd}')
    if ">" in cmd or ">>" in cmd:
        parts.append(f'echo "Redirects output to a file"')
    if "&&" in cmd:
        parts.append(f'echo "Chained commands — second runs only if first succeeds"')
    if "||" in cmd:
        parts.append(f'echo "Fallback — right side runs if left side fails"')
    if "rm -rf" in cmd or "rm -r" in cmd:
        parts.append(f'echo "DANGER: rm -r will DELETE files/directories permanently"')
    if "rm " in cmd and "-rf" not in cmd:
        parts.append(f'echo "This will DELETE files — make sure you have backups"')
    if cmd.startswith("cd "):
        parts.append(f'echo "Changes directory"')
    if "sudo" in cmd:
        parts.append(f'echo "sudo requires root — Termux does not support sudo by default"')
    if "apt " in cmd or "pkg " in cmd:
        parts.append(f'echo "Package manager operation"')
    if "git " in cmd:
        parts.append(f'echo "Git version control operation"')
    if "pip " in cmd:
        parts.append(f'echo "Python package manager (pip)"')
    if "npm " in cmd:
        parts.append(f'echo "Node.js package manager (npm)"')

    first_word = cmd.split()[0] if cmd.split() else ""
    if first_word:
        parts.append(f'echo "---"')
        qfirst = shell_quote(first_word)
        parts.append(f'which {qfirst} 2>/dev/null && echo "Command found" || echo "Command NOT found — you may need to install it"')

    script = " && ".join(parts) if parts else f'echo Command: {qcmd}'
    execute_streaming(handler, f'{script} && echo "---" && echo Original command: {qcmd}')



def handle_dev_env(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    intent = data.get("intent", "python").strip().lower()
    cwd = get_current_dir()
    project_name = data.get("name", "myproject").strip()
    qname = shell_quote(project_name)

    setups = {
        "python": (
            "Python Web Development",
            f'pkg install -y python python-pip 2>&1 | tail -5 && '
            f'pip install flask gunicorn 2>&1 | tail -5 && '
            f'mkdir -p {shell_quote(cwd + "/" + project_name)} && '
            f'cd {shell_quote(cwd + "/" + project_name)} && '
            f'echo "from flask import Flask\\napp = Flask(__name__)\\n@app.route(\'/\')\\ndef hello():\\n    return {{\'status\': \'ok\'}}\\nif __name__ == \'__main__\':\\n    app.run(host=\'0.0.0.0\', port=5000)" > app.py && '
            f'echo Created: {qname}/app.py && '
            f'echo Run: cd {qname} && python app.py'
        ),
        "bot": (
            "Telegram/Discord Bot",
            f'pkg install -y python python-pip 2>&1 | tail -3 && '
            f'pip install python-telegram-bot discord.py 2>&1 | tail -3 && '
            f'mkdir -p {shell_quote(cwd + "/" + project_name)} && '
            f'cd {shell_quote(cwd + "/" + project_name)} && '
            f'echo "# Bot token (get from @BotFather or Discord Developer Portal)\\nTOKEN = \'your_token_here\'\\nprint(\'Bot ready!\')" > bot.py && '
            f'echo Created: {qname}/bot.py'
        ),
        "react": (
            "React Frontend",
            f'pkg install -y nodejs 2>&1 | tail -3 && '
            f'npm --version 2>&1 && '
            f'cd {shell_quote(cwd)} && '
            f'echo {shell_quote("Run: npx create-react-app " + project_name)}'
        ),
        "node": (
            "Node.js Backend",
            f'pkg install -y nodejs 2>&1 | tail -3 && '
            f'mkdir -p {shell_quote(cwd + "/" + project_name)} && '
            f'cd {shell_quote(cwd + "/" + project_name)} && '
            f'npm init -y 2>&1 | tail -3 && '
            f'echo "console.log(\'Server ready\');" > index.js && '
            f'echo {shell_quote("Created: " + project_name + "/index.js")}'
        ),
        "c": (
            "C/C++ Development",
            f'pkg install -y clang make gdb 2>&1 | tail -3 && '
            f'mkdir -p {shell_quote(cwd + "/" + project_name)} && '
            f'cd {shell_quote(cwd + "/" + project_name)} && '
            f'echo "#include <stdio.h>\\nint main() {{\\n    printf(\\"Hello from Termux!\\\\n\\");\\n    return 0;\\n}}" > main.c && '
            f'echo {shell_quote("Created: " + project_name + "/main.c")} && '
            f'echo {shell_quote("Compile: cd " + project_name + " && clang main.c -o main && ./main")}'
        ),
        "rust": (
            "Rust Development",
            f'pkg install -y rust binutils 2>&1 | tail -3 && '
            f'cd {shell_quote(cwd)} && '
            f'cargo new {shell_quote(project_name)} 2>&1 && '
            f'echo {shell_quote("Created: " + project_name + "/")} && '
            f'echo {shell_quote("Run: cd " + project_name + " && cargo run")}'
        ),
        "data": (
            "Data Science",
            f'pkg install -y python python-pip 2>&1 | tail -3 && '
            f'pip install numpy pandas matplotlib jupyter 2>&1 | tail -5 && '
            f'mkdir -p {shell_quote(cwd + "/" + project_name)} && '
            f'echo {shell_quote("Created: " + project_name + "/")} && '
            f'echo "Start Jupyter: jupyter notebook"'
        ),
        "termux": (
            "Beautiful Terminal",
            f'pkg install -y zsh eza bat neofetch git 2>&1 | tail -5 && '
            f'echo "Installing oh-my-zsh..." && '
            f'sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" "" --unattended 2>&1 | tail -5 && '
            f'echo "Done! Restart Termux or run: zsh"'
        ),
    }

    if intent in setups:
        title, cmd = setups[intent]
        execute_streaming(handler, f'echo "🚀 Setting up: {title}"; echo "---"; {cmd}')
    else:
        execute_streaming(handler, f'echo "Available environments:"; echo "python, bot, react, node, c, rust, data, termux"')



def handle_review(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    file_path = data.get("file", "").strip()
    if not file_path:
        json_response(handler, 400, {"error": "Missing 'file' path"})
        return

    safe_path = shell_quote(file_path)
    ext = os.path.splitext(file_path)[1].lower()

    checks = [
        f'echo {shell_quote("=== File: " + file_path + " ===")}',
        f'echo "Size: $(wc -c < {safe_path} 2>/dev/null) bytes, Lines: $(wc -l < {safe_path} 2>/dev/null)"',
        f'echo "---"',
        f'echo "Content:"',
        f'cat {safe_path} 2>/dev/null || echo "Cannot read file"',
    ]

    if ext == ".py":
        checks += [
            f'echo "---"',
            f'echo "=== Python Syntax Check ==="',
            f'python3 -m py_compile {safe_path} 2>&1 && echo "✅ Syntax OK" || echo "❌ Syntax Error"',
            f'echo "---"',
            f'echo "=== Unused Variables ==="',
            f"python3 -m flake8 {safe_path} --select F841 2>&1 | head -10 || echo 'flake8 not installed (pip install flake8)'",
        ]
    elif ext in (".sh", ".bash"):
        checks += [
            f'echo "---"',
            f'echo "=== Shell Syntax Check ==="',
            f'bash -n {safe_path} 2>&1 && echo "✅ Syntax OK" || echo "❌ Syntax Error"',
        ]
    elif ext in (".js", ".mjs"):
        checks += [
            f'echo "---"',
            f'echo "=== JS Syntax Check ==="',
            f'node --check {safe_path} 2>&1 && echo "✅ Syntax OK" || echo "❌ Syntax Error"',
        ]
    elif ext == ".c":
        checks += [
            f'echo "---"',
            f'echo "=== C Lint ==="',
            f'clang -fsyntax-only -Wall {safe_path} 2>&1 | head -20 || echo "clang not installed"',
        ]

    execute_streaming(handler, " && ".join(checks))



def handle_log_analyze(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    file_path = data.get("file", "").strip()
    if not file_path:
        json_response(handler, 400, {"error": "Missing 'file' path"})
        return

    safe_path = shell_quote(file_path)
    cmd = (
        f'echo {shell_quote("Analyzing: " + file_path)}; echo "---"; '
        f'echo "Last 200 lines:"; '
        f'tail -200 {safe_path} 2>/dev/null || echo "Cannot read file"; '
        f'echo "---"; '
        f'echo "Errors found:"; '
        f'grep -i -E "error|fail|crash|fatal|exception|traceback|panic|segfault" {safe_path} 2>/dev/null | tail -30 || echo "No errors detected"'
    )
    execute_streaming(handler, cmd)



def handle_script_gen(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    description = data.get("description", "").strip()
    script_type = data.get("type", "sh").strip()
    output = data.get("output", "").strip()

    if not description:
        json_response(handler, 400, {"error": "Missing 'description' of what the script should do"})
        return

    safe_out = shell_quote(output) if output else ""
    if script_type == "py":
        header = (f"#!/usr/bin/env python3\\n# Script: {output or 'script.py'}"
                  f"\\n# {description}\\n")
        template = (f'echo {shell_quote(header)} > {safe_out} && '
                    f'echo {shell_quote("Python template created: " + output)}')
    else:
        header = (f"#!/data/data/com.termux/files/usr/bin/bash"
                  f"\\n# Script: {output or 'script.sh'}"
                  f"\\n# {description}\\n\\nset -e\\n")
        template = (f'echo {shell_quote(header)} > {safe_out} && '
                    f'chmod +x {safe_out} && '
                    f'echo {shell_quote("Bash script created: " + output)}')

    if output:
        execute_streaming(handler, template)
    else:
        execute_streaming(
            handler,
            f'echo {shell_quote("Script described: " + description)}\n'
            f'echo "To generate, provide an output path"')



def handle_deps_tree(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    package = data.get("package", "").strip()
    if package:
        execute_streaming(handler,
            f'echo {shell_quote("=== Reverse depends for: " + package + " ===")} && '
            f'apt-cache rdepends {shell_quote(package)} 2>/dev/null | head -30 || '
            f'echo "Package not found"'
        )
    else:
        execute_streaming(handler,
            f'echo "=== Installed Packages ===" && '
            f'pkg list-installed 2>/dev/null | wc -l && echo "packages total" && '
            f'echo "---" && '
            f'echo "Top 20 by size:" && '
            f'dpkg-query -W -f=\'${{Installed-Size}}\\t${{Package}}\\n\' 2>/dev/null | sort -rn | head -20 || '
            f'echo "Use dpkg-query for package sizes"'
        )



def handle_storage_audit(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    execute_streaming(handler,
        'echo "=== Storage Usage ==="; '
        'df -h /data 2>/dev/null | tail -1; '
        'echo "---"; '
        'echo "Largest directories in ~/:"; '
        'du -sh ~/*/ 2>/dev/null | sort -rh | head -15; '
        'echo "---"; '
        'echo "Cache directories:"; '
        'du -sh ~/.cache/*/ 2>/dev/null | sort -rh | head -10; '
        'echo "---"; '
        'echo "Pip cache:"; '
        'du -sh ~/.cache/pip 2>/dev/null || echo "No pip cache"; '
        'echo "---"; '
        'echo "npm cache:"; '
        'du -sh ~/.npm 2>/dev/null || echo "No npm cache"; '
        'echo "---"; '
        'echo "Trash/Downloads:"; '
        'du -sh ~/storage/downloads/ 2>/dev/null || echo "No downloads folder"; '
        'echo "---"; '
        'echo "💡 Cleanup commands:"; '
        'echo "  pip cache purge"; '
        'echo "  npm cache clean --force"; '
        'echo "  pkg clean"; '
        'echo "  rm -rf ~/.cache/pip"'
    )



def handle_config_fix(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    which_config = data.get("config", "all").strip()

    checks = []
    if which_config in ("bashrc", "all"):
        checks.append('echo "=== .bashrc ===" && cat ~/.bashrc 2>/dev/null | head -50 || echo "No .bashrc found"')
    if which_config in ("zshrc", "all"):
        checks.append('echo "=== .zshrc ===" && cat ~/.zshrc 2>/dev/null | head -50 || echo "No .zshrc found"')
    if which_config in ("termux", "all"):
        checks.append('echo "=== termux.properties ===" && cat ~/.termux/termux.properties 2>/dev/null || echo "No termux.properties"')
    if which_config in ("font", "all"):
        checks.append('echo "=== Font ===" && ls ~/.termux/font.ttf 2>/dev/null && echo "Custom font found" || echo "Default font"')
    if which_config in ("colors", "all"):
        checks.append('echo "=== colors.properties ===" && cat ~/.termux/colors.properties 2>/dev/null || echo "Default colors"')
    if which_config in ("storage", "all"):
        checks.append('echo "=== Storage Check ===" && ls ~/storage/ 2>/dev/null || echo "Storage NOT set up — run: termux-setup-storage"')
    if which_config in ("path", "all"):
        checks.append(r'echo "=== $PATH ===" && echo "$PATH"')
    if which_config in ("env", "all"):
        checks.append('echo "=== Environment ===" && env | sort | head -30')

    cmd = " && ".join(checks) if checks else 'echo Specify: bashrc, zshrc, termux, font, colors, storage, path, env, or all'
    execute_streaming(handler, cmd)



def handle_git_smart(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    action = data.get("action", "diff").strip()
    repo_dir = data.get("repo_dir", get_current_dir()).strip()
    safe_dir = shell_quote(repo_dir)

    if action == "diff-summary":
        cmd = f'cd {safe_dir} && echo "=== Files Changed ===" && git diff --stat 2>&1 | tail -20 && echo "---" && echo "=== Diff ===" && git diff --unified=5 2>&1 | head -200'
    elif action == "log-recent":
        try:
            limit = require_int(data.get("limit", 10))
        except ValueError:
            json_response(handler, 400, {"error": "Valid 'limit' required"})
            return
        cmd = f'cd {safe_dir} && git log --oneline --graph -{limit} 2>&1'
    elif action == "suggest-commit":
        cmd = f'cd {safe_dir} && echo "=== Current Changes ===" && git diff --stat 2>&1 && echo "---" && echo "Suggested commit message:" && git diff --cached 2>&1 | head -50 || git diff 2>&1 | head -50'
    elif action == "fix-conflict":
        cmd = f'cd {safe_dir} && echo "=== Conflict Status ===" && git diff --name-only --diff-filter=U 2>&1 && echo "---" && echo "Files with conflicts:" && git diff --check 2>&1 | head -20'
    else:
        if not action or set(action) - GIT_SMART_ACTION_CHARS:
            json_response(handler, 400,
                          {"error": f"Unsupported git action: {action}"})
            return
        cmd = f'cd {safe_dir} && git {action} 2>&1 | tail -30'

    execute_streaming(handler, cmd)



def handle_regex(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    pattern = data.get("pattern", "").strip()
    test_str = data.get("test", "").strip()

    if not pattern:
        json_response(handler, 400, {"error": "Missing 'pattern'"})
        return

    safe_pattern = shell_quote(pattern)
    if test_str:
        safe_test = shell_quote(test_str)
        cmd = (
            f'echo {shell_quote("Pattern: " + pattern)} && '
            f'echo {shell_quote("Test: " + test_str)} && '
            f'echo "---" && '
            f'echo "Matches:" && '
            f'echo {safe_test} | grep -oP {safe_pattern} 2>&1 || echo "No matches or invalid regex"'
        )
    else:
        cmd = (f'echo {shell_quote("Pattern: " + pattern)} && '
               f'echo "Provide a test string to check matches"')

    execute_streaming(handler, cmd)



def handle_db_design(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    schema = data.get("schema", "").strip()
    db_path = data.get("output", get_current_dir() + "/database.sqlite").strip()

    if not schema:
        json_response(handler, 400, {"error": "Missing 'schema' — describe your tables"})
        return

    safe_db = shell_quote(db_path)
    cmd = (
        f'touch {safe_db} 2>/dev/null && '
        f'echo {shell_quote("Database created: " + db_path)} && '
        f'echo "---" && '
        f'echo "Schema description:" && '
        f'echo {shell_quote(schema)} && '
        f'echo "---" && '
        f'echo "Use /db-query to run SQL. Example: CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT);"'
    )
    execute_streaming(handler, cmd)



def handle_backup(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    target = data.get("target", "home").strip()
    output = data.get("output", "").strip()
    include = data.get("include", "").strip().split(",") if data.get("include", "").strip() else []

    import time
    home = os.environ.get("HOME", "/data/data/com.termux/files/home")
    timestamp = time.strftime("%Y%m%d_%H%M%S")

    if not output:
        output = f"~/storage/shared/termux_backup_{timestamp}.tar.gz"

    safe_out = shell_quote(output)

    if target == "home":
        cmd = (
            f'mkdir -p "$(dirname {safe_out})" 2>/dev/null; '
            f'echo "Backing up: {home}"; '
            f'echo {shell_quote("Output: " + output)}; '
            f'echo "---"; '
            f'tar -czvf {safe_out} -C "$(dirname {home})" "$(basename {home})" --exclude=".cache" --exclude="__pycache__" --exclude="node_modules" --exclude="*.pyc" 2>&1 | while read line; do echo "$line"; done && '
            f'echo "" && '
            f'echo "✅ Backup complete!" && '
            f'ls -lh {safe_out} || echo "❌ Backup failed"'
        )
    elif target == "packages":
        cmd = (
            f'echo "Backing up package list..." && '
            f'pkg list-installed > {safe_out} 2>&1 && '
            f'echo {shell_quote("✅ Package list saved to: " + output)} && '
            f'echo "Restore with: xargs pkg install -y < {safe_out}"'
        )
    elif target == "configs":
        cmd = (
            f'echo "Backing up configs..." && '
            f'tar -czf {safe_out} ~/.bashrc ~/.zshrc ~/.termux/ ~/.config/ 2>/dev/null && '
            f'echo {shell_quote("✅ Configs saved to: " + output)} && '
            f'ls -lh {safe_out}'
        )
    elif include:
        inc_paths = " ".join(shell_quote(p.strip()) for p in include if p.strip())
        cmd = (
            f'mkdir -p "$(dirname {safe_out})" 2>/dev/null; '
            f'echo "Backing up selected paths..." && '
            f'tar -czf {safe_out} {inc_paths} 2>&1 && '
            f'echo {shell_quote("✅ Backup complete: " + output)} && '
            f'ls -lh {safe_out} || echo "❌ Backup failed"'
        )
    else:
        cmd = 'echo "Targets: home, packages, configs. Or specify include: path1,path2"'

    execute_streaming(handler, cmd)



def handle_restore(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    backup_file = data.get("file", "").strip()
    target = data.get("target", "home").strip()

    if not backup_file:
        json_response(handler, 400, {"error": "Missing 'file' — path to backup archive"})
        return

    safe_file = shell_quote(backup_file)
    home = os.environ.get("HOME", "/data/data/com.termux/files/home")

    if target == "home":
        cmd = (
            f'echo "⚠️ WARNING: This will overwrite files in {home}"; '
            f'echo {shell_quote("Restoring from: " + backup_file)}; '
            f'echo "---"; '
            f'tar -xzf {safe_file} -C "$(dirname {home})" 2>&1 && '
            f'echo "✅ Restore complete!" || echo "❌ Restore failed"'
        )
    elif target == "packages":
        cmd = (
            f'echo {shell_quote("Restoring packages from: " + backup_file)}; '
            f'xargs pkg install -y < {safe_file} 2>&1 | tail -20 && '
            f'echo "✅ Packages restored!" || echo "❌ Restore failed"'
        )
    elif target == "configs":
        cmd = (
            f'echo {shell_quote("Restoring configs from: " + backup_file)}; '
            f'tar -xzf {safe_file} -C {shell_quote(home)} 2>&1 && '
            f'echo "✅ Configs restored!" || echo "❌ Restore failed"'
        )
    elif target == "info":
        cmd = (
            f'echo "=== Backup Info ===" && '
            f'echo {shell_quote("File: " + backup_file)} && '
            f'tar -tzf {safe_file} 2>/dev/null | head -50 && '
            f'echo "---" && '
            f'tar -tzf {safe_file} 2>/dev/null | wc -l && echo "files total"'
        )
    else:
        cmd = 'echo "Targets: home, packages, configs, info"'

    execute_streaming(handler, cmd)


def handle_changes_list(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    root = safety_root("")
    entries = changes.read(root,
                           limit=_as_int(data.get("limit"), 50),
                           since=str(data.get("since") or "").strip(),
                           task=str(data.get("task_id") or "").strip())
    if str(data.get("format") or "").strip().lower() == "json":
        json_response(handler, 200, {
            "changes": [dict(entry, revertable=changes.revertable(entry, root),
                             undo=changes.undo_command(entry) if entry.get("kind") in changes.PACKAGE_KINDS else "")
                        for entry in entries],
        })
        return
    _text_response(handler, changes.summarise(entries))


def handle_undo(handler: "BaseHTTPRequestHandler", data: dict) -> None:
    root = safety_root("")
    wanted = str(data.get("path") or "").strip()
    entries = [e for e in changes.read(root,
                                       limit=_as_int(data.get("limit"), 50),
                                       since=str(data.get("since") or "").strip(),
                                       task=str(data.get("task_id") or "").strip())
               if changes.revertable(e, root)
               and (not wanted or e.get("path") == wanted)]
    if not entries:
        _text_response(handler, "Nothing to undo.")
        return
    if not data.get("confirmed"):
        json_response(handler, 200, {
            "status": "confirmation_required",
            "requires_confirmation": True,
            "paths": [e.get("path") for e in entries],
            "message": f"Undoing {len(entries)} change(s).",
            "commands": [changes.undo_command(e) for e in entries if e.get("kind") in changes.PACKAGE_KINDS],
        })
        return
    done = changes.revert(entries, snapshot_before=snapshot_before_write, root=root)
    body = "\n".join(f"{what}: {path}" for path, what in done)
    _text_response(handler, f"Undone {len(done)} change(s):\n{body}")
