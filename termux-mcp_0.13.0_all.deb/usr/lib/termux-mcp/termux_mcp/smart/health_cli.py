"""Entry point the reactor runs for the daily health check."""
from . import health

if __name__ == "__main__":
    r = health.run()
    print(r.get("summary", ""))
